# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
from pymongo.errors import ConnectionFailure, OperationFailure

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'yourSecurePassword123'   
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Initialize Connection
        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
            print("MongoDB connection successful.")
        except ConnectionFailure as e:
            print(f"Could not connect to MongoDB: {e}")
            raise

    # CREATE method
    def create(self, data):
        """
        Insert a document into the collection.
        :param data: dictionary of key/value pairs
        :return: True if successful, False otherwise
        """
        if data is not None and isinstance(data, dict):
            try:
                result = self.collection.insert_one(data)
                return True if result.inserted_id else False
            except OperationFailure as e:
                print(f"Insert failed: {e}")
                return False
        else:
            print("Invalid data format. Must be a dictionary.")
            return False

    # READ method
    def read(self, query):
        """
        Query documents from the collection.
        :param query: dictionary key/value lookup pair
        :return: list of documents if successful, else empty list
        """
        if query is not None and isinstance(query, dict):
            try:
                cursor = self.collection.find(query)
                results = list(cursor)
                return results
            except OperationFailure as e:
                print(f"Query failed: {e}")
                return []
        else:
            print("Invalid query format. Must be a dictionary.")
            return []

    # Create method to implement the R in CRUD.
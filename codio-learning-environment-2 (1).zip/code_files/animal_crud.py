# animal_crud.py
from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter:
    def __init__(self, username, password, db_name='aac', collection_name='animals'):
        try:
            connection_string = f'mongodb://{username}:{password}@localhost:27017'
            print(f"Connecting with: {connection_string}")
            self.client = MongoClient(connection_string)
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
        except PyMongoError as e:
            print(f"Connection error: {e}")
            self.collection = None

    def create(self, data):
        """
        Insert a document into the collection.
        Returns True if successful, else False.
        """
        if data and isinstance(data, dict):
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except PyMongoError as e:
                print(f"Create error: {e}")
        return False

    def read(self, query):
        """
        Query documents from the collection using find().
        Returns a list of results or an empty list.
        """
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, new_values):
        """
        Update documents matching the query.
        Returns the number of documents modified.
        """
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query):
        """
        Delete documents matching the query.
        Returns the number of documents deleted.
        """
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0
